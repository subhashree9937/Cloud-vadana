document.getElementById('surveyForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert("Form submitted!");
});

document.getElementById('resetBtn').addEventListener('click', function() {
    document.getElementById('surveyForm').reset();
});